function f1(){

}
function f2(){

}
function test1(){
  f1();
  f2();
}
test1();

function p1(){

}
function p2(){

}
function test2(){
  p1();
  p2();
}
// test2();

function test3(){
  p1();
  p2();
}
// test3();