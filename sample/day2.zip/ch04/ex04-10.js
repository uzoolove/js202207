// 함수의 인자로 전달될 수 있다.
function foo(){
	console.log('foo 호출.');
};

function bar(){
	console.log('bar 호출.');
};

foo();
