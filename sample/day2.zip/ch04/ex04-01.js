// 선언문 방식의 함수 선언


console.log(add(10, 20));